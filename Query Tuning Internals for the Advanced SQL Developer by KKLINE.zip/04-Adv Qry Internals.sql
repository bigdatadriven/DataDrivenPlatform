------------------------------------------------------------
-- Parsing 
------------------------------------------------------------

-- Turn on PARSEONLY.  This directs the query processor to only execute the "parse" phase.
SET PARSEONLY ON;

-- The following is a valid, executable query.  However, we get no results back because 
-- all SQL is doing is validating the syntax.

-- Also note that we cannot get an execution plan.

USE CorpDB;
GO

SELECT * FROM CorpDB.dbo.Customer;
GO

-- The following is a valid query but cannot be executed because the table doesn't exist.  However, it
-- will still run without error in a proc because it is syntactically correct.

SELECT NonExistantColumn FROM NonExistantTable;

-- Cleanup.

SET PARSEONLY OFF;

------------------------------------------------------------
-- Binding 
------------------------------------------------------------

-- Data type resolution.
-- Even though CustomerID and OrderId have completely different meanings, we can still union
-- the results together because they have the same data type (int).

SELECT c.CustomerID
FROM CorpDB.dbo.Customer c
UNION
SELECT oh.OrderId
FROM CorpDB.dbo.OrderHeader oh;

-- However, FirstName is of type varchar() and OrderDate is datetime2.  These types are
-- incompatible and we will get an error.  This error happens during the binding process
-- and before optimization begins.

SELECT c.CustomerID, c.FirstName
FROM CorpDB.dbo.Customer c
UNION
SELECT oh.OrderId, oh.OrderDate
FROM CorpDB.dbo.OrderHeader oh;

-- Msg 241, Level 16, State 1, Line ##
-- Conversion failed when converting date and/or time from character string.

-- Aggregate binding. &&&
-- This query will generate an error during the binding process because SQL knows that
-- "FirstName" is not a valid column because it is neither in the group by clause nor
-- is it an aggregate.

SELECT c.LastName, c.FirstName, COUNT(*) NbrCustomers
FROM CorpDB.dbo.Customer c
GROUP BY c.LastName;

-- Msg 8120, Level 16, State 1, Line ##
-- Column 'CorpDB.dbo.Customer.FirstName' is invalid in the select list because it is not 
-- contained in either an aggregate function or the GROUP BY clause.

------------------------------------------------------------
-- Trivial Plans 
------------------------------------------------------------

-- Get an estimated execution plan on this query.
-- Get the "F4" properties and select the root node.
-- Note that "Optimization Level" = TRIVIAL

SELECT *
FROM CorpDB.dbo.Customer c;

-- Same thing with a WHERE clause

SELECT *
FROM CorpDB.dbo.Customer c
WHERE c.State = 'NE';

-- Now let's add an index on State.

IF EXISTS (SELECT * FROM CorpDB.sys.indexes WHERE name = 'idx_Customer__State')
	DROP INDEX dbo.Customer.idx_Customer__State;

CREATE INDEX idx_Customer__State ON CorpDB.dbo.Customer (State);

-- Now get the estimated plan.
-- We still wind up with the same plan, but because SQL had alternative to consider this is no
-- longer a trivial plan.  "Optimization Level" = FULL.

SELECT *
FROM CorpDB.dbo.Customer c
WHERE c.State = 'NE'
OPTION (RECOMPILE);

-- Cleanup

IF EXISTS (SELECT * FROM CorpDB.sys.indexes WHERE name = 'idx_Customer__State')
	DROP INDEX dbo.Customer.idx_Customer__State;


-- Note that you can prevent generating a trivial plan using TF8757.


------------------------------------------------------------
-- Simplifications 
------------------------------------------------------------

-- Turn on TF3604 for the session.  This will cause output to be written back the client 
-- (SSMS - on the messages tab).
DBCC TRACEON (3604);

-- Subquery to INNER JOIN transformation. Note the semi-join operator
SELECT oh.OrderId, oh.OrderDate, oh.CustomerId
FROM CorpDB.dbo.OrderHeader oh
WHERE oh.CustomerId IN
	(
		SELECT c.CustomerId
		FROM CorpDB.dbo.Customer c
		WHERE c.State = 'NE'
	)
OPTION (RECOMPILE, QUERYTRACEON 8606);

-- Example of a plan with multiple tables but which is still trivial due to simplification.
WITH ALLDATA AS
(
	SELECT od.ProductId, p.ProductName, od.OrderId, od.Quantity, od.UnitPrice,
		oh.OrderDate, c.CustomerID, c.FirstName, c.LastName
	FROM CorpDB.dbo.Product p
	FULL JOIN CorpDB.dbo.OrderDetail od ON od.ProductId = p.ProductId
	FULL JOIN CorpDB.dbo.OrderHeader oh ON oh.OrderId = od.OrderId
	FULL JOIN CorpDB.dbo.Customer c ON c.CustomerID = oh.CustomerId
)
SELECT ad.OrderId, ad.Quantity, ad.UnitPrice
FROM AllData ad
WHERE ad.ProductId = 7304;

-- This is because simplification rules optimize away all but the OrderDetail table,
-- so this query is essentially:
--     SELECT od.OrderId, od.Quantity, od.UnitPrice
--     FROM CorpDB.dbo.OrderDetail od
--     WHERE od.ProductId = 7304;

-- Subquery to INNER JOIN transformation. 
-- Note how the "simplified" tree treats the query as if it had been written without 
-- the subquery.
SELECT CustomerOrderView.OrderId, CustomerOrderView.CustomerId, od.ProductId
FROM CorpDB.dbo.OrderDetail od
	INNER JOIN
	(
		SELECT oh.OrderId, oh.CustomerId, c.State
		FROM CorpDB.dbo.OrderHeader oh
		INNER JOIN CorpDB.dbo.Customer c on oh.CustomerId = c.CustomerId
	) CustomerOrderView on od.OrderId = CustomerOrderView.OrderId
WHERE CustomerOrderView.State = 'NE'
OPTION (MAXDOP 1, RECOMPILE, QUERYTRACEON 8605, QUERYTRACEON 8606);

-- Predicate pushdown
-- Note in the Simplified Tree that the SELECT operator is pushed below the 
-- join where to "the data lives"
SELECT oh.OrderId, oh.OrderDate, oh.CustomerId
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.Customer c on oh.CustomerId = c.CustomerID
WHERE c.State = 'NE'
OPTION (RECOMPILE, QUERYTRACEON 8605, QUERYTRACEON 8606);

-- Foreign key table removal
-- Note that in the join-collapsed tree, Customer has been removed entirely.
SELECT oh.OrderId, oh.OrderDate, oh.CustomerId
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.Customer c on oh.CustomerId = c.CustomerID
OPTION (RECOMPILE, QUERYTRACEON 8605, querytraceon 8606);

-- Contradiction detection
SELECT p.ProductId, p.ProductName, p.UnitPrice
FROM CorpDB.dbo.Product p
	INNER JOIN CorpDB.dbo.OrderDetail od on od.ProductId = p.ProductId
WHERE p.UnitPrice > 50.00
	AND p.UnitPrice < 25.00
OPTION (RECOMPILE, QUERYTRACEON 8605, querytraceon 8606);

------------------------------------------------------------
-- Trivial Plans
------------------------------------------------------------

-- Get an estimated execution plan on this query.
-- Get the "F4" properties and select the root node.
-- Note that "Optimization Level" = TRIVIAL

SELECT *
FROM CorpDB.dbo.Customer c;

-- Same thing with a WHERE clause
SELECT *
FROM CorpDB.dbo.Customer c
WHERE c.State = 'NE';

-- Now let's add an index on State.
IF EXISTS (SELECT * FROM CorpDB.sys.indexes WHERE name = 'idx_Customer__State')
	DROP INDEX dbo.Customer.idx_Customer__State;

CREATE INDEX idx_Customer__State ON CorpDB.dbo.Customer (State);

-- Now get the estimated plan.
-- We still wind up with the same plan, but because SQL had alternative to consider this is no
-- longer a trivial plan.  "Optimization Level" = FULL.
SELECT *
FROM CorpDB.dbo.Customer c
WHERE c.State = 'NE'
OPTION (RECOMPILE);

-- Cleanup
IF EXISTS (SELECT * FROM CorpDB.sys.indexes WHERE name = 'idx_Customer__State')
	DROP INDEX dbo.Customer.idx_Customer__State;


-- Note that you can prevent generating a trivial plan using TF8757.

-----------------------------------------------------------------------------------------------------------------------
-- Memos Structures
-----------------------------------------------------------------------------------------------------------------------

DBCC TRACEON (3604);

-- Start with a very simple (in fact, technically trivial) query.
-- TF8757 turns off trivial plans.
-- TF8608 will output the initial memo structure.
-- TF8615 shows the final memo structure.

SELECT *
FROM CorpDB.dbo.Customer c
OPTION (RECOMPILE, QUERYTRACEON 8757, QUERYTRACEON 8615);

-- Now with a WHERE clause
SELECT *
FROM CorpDB.dbo.Customer c
WHERE c.State = 'NE'
OPTION (RECOMPILE, QUERYTRACEON 8757, QUERYTRACEON 8615);

-- Now add a JOIN
SELECT *
FROM CorpDB.dbo.Customer c
	INNER JOIN CorpDB.dbo.OrderHeader oh ON oh.CustomerId = c.CustomerID
WHERE c.State = 'NE'
OPTION (RECOMPILE, QUERYTRACEON 8615);

-- Same query as above.  Get an estimated query plan.
-- TF9130 will show the pushed predicate in the query plan. &&&
SELECT *
FROM CorpDB.dbo.Customer c
	INNER JOIN CorpDB.dbo.OrderHeader oh ON oh.CustomerId = c.CustomerID
WHERE c.State = 'NE'
OPTION (RECOMPILE, QUERYTRACEON 8615, QUERYTRACEON 9130);

