------------------------------------------------------------
-- Undocumented DBCC 
------------------------------------------------------------
DBCC TRACEON (3604);
GO

DBCC TRACEON (2588);
GO

DBCC HELP ('?');
GO

DBCC HELP ('autopilot'); -- What shall we try?
GO

/*
-- There are differences between the 2008 and 2008 R2 versions. 
-- The following commands exist in 2008/R2 but were gone in the next:
 
DBCC ACTIVECURSORS
DBCC DBRECOVER
DBCC ICECAPQUERY
DBCC LATCH
DBCC METADATA
DBCC MOVEPAGE
DBCC PRTIPAGE
DBCC SHOWDBAFFINITY
DBCC SHOWTABLEAFFINITY

-- SQL2012 brought three new commands:
 
DBCC CRASHDB
DBCC CSINDEX
DBCC readBytes

-- SQL2014 CTP2 (12.0.1524) delivered one more:
 
DBCC FLUSHQUERYSTORE
*/

DBCC SHOWONRULES;
GO

DBCC RULEOFF('JNtoHS');
GO

-- We can also at any time identify the rules are currently enabled.

DBCC TRACEON (3604);
DBCC SHOWONRULES;

-- Or which rules are currently disabled.

DBCC TRACEON (3604);
DBCC SHOWOFFRULES;

-- Cleanup

DBCC RULEON ('JNtoHS');
DBCC RULEON ('GbAggToHS');
DBCC RULEON ('HJwBMtoHS');
