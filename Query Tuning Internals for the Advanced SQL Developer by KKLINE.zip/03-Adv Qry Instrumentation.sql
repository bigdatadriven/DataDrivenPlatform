-----------------------------------------------------------------------------------------------------------------------
-- Transformation Stats
-----------------------------------------------------------------------------------------------------------------------

-- sys.dm_exec_query_transformation_stats shows one record for each transformation 
-- rule that the optimizer has enabled.
-- It includes some "promise" information that is a guess about how effective the 
-- rule will be under the current circumstances (which allows the optimizer to 
-- prioritize rules).  It also contains columns indicating how successful the 
-- transformation was.

-- The rule names can be difficult, especially at first, to figure out.  Suggestion: 
-- do a web search on a rule name.

-- The stats are accumulated since the instance start, so just SELECTing FROM the 
-- table is not terribly useful.
-----------------------------------------------------------------------------------------------------------------------

SELECT *
FROM sys.dm_exec_query_transformation_stats;

-----------------------------------------------------------------------------------------------------------------------
-- Running totals for sys.dm_exec_query_transformation_stats
-----------------------------------------------------------------------------------------------------------------------

-- The following statements will take a snapshot of sys.dm_exec_query_transformation_stats before and after a
-- query of interest gets executed.  We have to execute the exact two SELECT ... INTO statements and the drop
-- statements ahead of time to make sure they are in the plan cache and don't go through the optimizer when
-- we run them again.  Also, other queries running concurrently will skew the results, so this needs to happen
-- on a quiet system.  If we run these statements (with no "query of interest") we should get no results.

SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
GO
SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
-----------------------------------------------------------------------------------------------------------------------
-- Insert query of interest here
-----------------------------------------------------------------------------------------------------------------------

SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
SELECT a.name, a.promised - b.promised promised, a.succeeded - b.succeeded succeeded
FROM #before_transf_stats b
	JOIN #after_transf_stats a on a.name = b.name
WHERE a.succeeded != b.succeeded
ORDER BY name;
GO

IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
GO
-----------------------------------------------------------------------------------------------------------------------
-- End
-----------------------------------------------------------------------------------------------------------------------

-- Now let's try this on one of our queries.

-----------------------------------------------------------------------------------------------------------------------
-- Begin
-----------------------------------------------------------------------------------------------------------------------

SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
GO
SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
-----------------------------------------------------------------------------------------------------------------------
-- Insert query of interest here
-----------------------------------------------------------------------------------------------------------------------
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE);
GO

SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO

SELECT a.name, a.promised - b.promised promised, a.succeeded - b.succeeded succeeded
FROM #before_transf_stats b
	JOIN #after_transf_stats a on a.name = b.name
WHERE a.succeeded != b.succeeded
ORDER BY name;
GO

IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
GO
-----------------------------------------------------------------------------------------------------------------------
-- End of running totals
-----------------------------------------------------------------------------------------------------------------------

-- Now get an estimated execution plan on this query.  Note the plan cost.

SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE);

-- Notice that in the execution plan we had a couple of hash JOINs and one hash 
-- aggregation. Suppose we want to try the query again and see what happens if we 
-- don't allow SQL to consider hash JOINs and aggregates.
-- We eliminate the hash JOIN and aggregate, and instead use merge JOIN and stream 
-- aggregate.  However, a couple of sorts have to be introduced to support this 
-- operator.

DBCC RULEOFF ('JNtoHS');
DBCC RULEOFF ('GbAggToHS');
DBCC RULEOFF ('HJwBMtoHS');
GO

-- Get the estimated query plan again.

SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE);
GO
-----------------------------------------------------------------------------------------------------------------------
-- Begin
-----------------------------------------------------------------------------------------------------------------------

SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO
IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
go
SELECT * INTO #before_transf_stats FROM sys.dm_exec_query_transformation_stats;
go
-----------------------------------------------------------------------------------------------------------------------
-- Insert query of interest here
-----------------------------------------------------------------------------------------------------------------------
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE);
GO

SELECT * INTO #after_transf_stats FROM sys.dm_exec_query_transformation_stats;
GO

SELECT a.name, a.promised - b.promised promised, a.succeeded - b.succeeded succeeded
FROM #before_transf_stats b
	JOIN #after_transf_stats a on a.name = b.name
WHERE a.succeeded != b.succeeded
ORDER BY name;
GO

IF OBJECT_ID('tempdb..#before_transf_stats') IS NOT NULL DROP TABLE #before_transf_stats;
IF OBJECT_ID('tempdb..#after_transf_stats') IS NOT NULL DROP TABLE #after_transf_stats;
go
-----------------------------------------------------------------------------------------------------------------------
-- End
-----------------------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------------------
-- Hey, Kevin, I prefer Xevents. What can I do?
-----------------------------------------------------------------------------------------------------------------------

CREATE EVENT SESSION [XeNewCE] ON SERVER
ADD EVENT sqlserver.query_optimizer_estimate_cardinality(
    ACTION(sqlserver.sql_text)),
ADD EVENT sqlserver.query_optimizer_force_both_cardinality_estimation_behaviors
ADD TARGET package0.event_file(SET filename=N'C:\Perflogs\XeNewCE.xel',max_file_size=(50),max_rollover_files=(2))
GO

ALTER EVENT SESSION [XeNewCE] ON SERVER STATE = START
GO

SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId

ALTER EVENT SESSION [XeNewCE] ON SERVER STATE = STOP;
GO

DROP EVENT SESSION [XeNewCE] ON SERVER;
GO

/*
What statistics are being used for a given query?

Then you can look at the XE session and look at the information there, such as:
-- Calculator is the algorithm used to estimate cardinality
-- -- Subcalculator shows predicate cardinality
-- Input_relation - shows input tree
-- StatsCollection will show the loaded statistics.
-- -- StatsCollectionID appears as a property of the operator in the plan as well.
-- -- The StatsCollectionID is in the Calculator which tells you what stats is used for what predicate.

Question: I remember reading/hearing, back when the new cardinality estimator was 
introduced, that for multiple predicates (WHERE City = 'Seattle' AND State = 'WA')  
SQL2014 would always use exponential backoff and never multi-column statistics even 
if they are available. (On the radar for change in a later service pack or major 
version).

Answer: Assuming you�re talking about multiple predicates from a single table, with the 
new CE, Independence Assumption becomes Correlation Assumption, where we assume that 
the combination of the different column values are not as independent. The assumption 
is that certain combinations of values are not coming up at all, whereas others are 
showing up more frequently. Therefore, with that assumption in mind, multi column stats 
were not used.

That is changing in SQL 2016, specifically, if there is a statistics object covering 
all the predicate�s columns, then selectivity can be derived from that multi-column 
statistic.
*/

-----------------------------------------------------------------------------------------------------------------------
-- sys.dm_exec_query_optimizer_info
-----------------------------------------------------------------------------------------------------------------------

SELECT *
FROM sys.dm_exec_query_optimizer_info
WHERE [counter] 
    IN ( 'optimizations', 'trivial plan', 'search 0', 'search 1', 'search 2' ); -- optimizer statistics events;
