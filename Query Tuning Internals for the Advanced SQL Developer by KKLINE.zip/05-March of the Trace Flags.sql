-- Query that shows join-collapse
SELECT oh.OrderId, oh.OrderDate, c.CustomerID, c.FirstName, c.LastName,
	od.OrderId, od.Quantity, od.UnitPrice
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.Customer c on c.CustomerID = oh.CustomerId
	INNER JOIN CorpDB.dbo.OrderDetail od on od.OrderId = oh.OrderId
OPTION (RECOMPILE, QUERYTRACEON 8605, QUERYTRACEON 8606);


-- March of the Trace Flags!

-- Related: TF8675 will show optimization phases and search times &&&
-- Note that the query runs Search 1 twice (once for serial, once for parallel)
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8675);

-- Related: TF8677 will force Search 2 (aka Phase 2) to run. &&&
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8677);

-- TF2372 will display information about memory usage during optimization 
-- for cached plan (bytes).
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 2372);

-- TF2373 will display information about memory usage. &&&
-- Quite verbose since it describes all optimizer rules.
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 2373);

-- Combine the two for a more complete picture.
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 2372, QUERYTRACEON 2373);

-- TF8619 shows more complex rules that are applied &&&
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8619);

-- Combine with TF8620 to show some memo-related information
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8619, QUERYTRACEON 8620);

-- TF8621 shows query tree after applying rules
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8621);

-- Combine TF8619/8620/8621 to get a fuller picture
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8619, QUERYTRACEON 8620, QUERYTRACEON 8621);

-- TF8609 to show task information &&&
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 8609);

-- Combine TF2372/2373/8619/8620/8621 to get very wide picture
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 2372, QUERYTRACEON 2373, QUERYTRACEON 8619, QUERYTRACEON 8620, QUERYTRACEON 8621);

-- Use trace flags 9292 and 9204 to show information about the statistics loaded 
--    during the optimization process.
SELECT TOP 5 od.ProductId, SUM(od.Quantity) - 20 ExcessOrders
FROM CorpDB.dbo.OrderHeader oh
	INNER JOIN CorpDB.dbo.OrderDetail od 
		ON oh.OrderId = od.OrderId
	INNER JOIN CorpDB.dbo.Customer cust 
		ON oh.CustomerId = cust.CustomerID
WHERE cust.State = 'NE'
GROUP BY od.ProductId
	HAVING SUM(od.Quantity) >= 20
ORDER BY od.ProductId
OPTION (RECOMPILE, QUERYTRACEON 9292, QUERYTRACEON 9204);

