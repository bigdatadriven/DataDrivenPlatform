USE AdventureWorks2014;
SET NOCOUNT ON;
GO

-- The column SalesPersonID is the leading key in index IX_SalesOrderHeader_SalesPersonID.
-- Which of the below queries, all of which filter on SalesPersonID, are SARGable,
-- meaning that they will use that index to seek out matching rows?

												-- SARGable?  Yes
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID = 283;
												-- SARGable?  Yes
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID >= 283;
												-- SARGable?  Depends... but usually yes.
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID <> 283;

SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID > 283 OR SalesPersonID < 283;

												-- SARGable?  Yes
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID IN 
		(SELECT BusinessEntityID 
		FROM Person.Person 
		WHERE LastName = 'Campbell' AND FirstName = 'David');

												-- SARGable?  No
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID NOT IN 
		(SELECT BusinessEntityID 
		FROM Person.Person 
		WHERE LastName = 'Campbell' 
		AND FirstName = 'David');

												-- SARGable?  No
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE ISNULL(SalesPersonID, 0) = 283;

												-- SARGable?  Yes
SELECT SalesOrderID 
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID IS NULL;

												-- Parameterization
SELECT ProductID, SalesOrderID
FROM Sales.SalesOrderDetail
WHERE ProductID > 100
ORDER BY ProductID;

SELECT ProductID, SalesOrderID
FROM Sales.SalesOrderDetail
WHERE ProductID > 200
ORDER BY ProductID;

												-- The Impact of Sort Operations
SELECT * 
FROM Sales.SalesOrderHeader AS h
   INNER JOIN Sales.SalesOrderDetail AS d
      ON h.SalesOrderID = d.SalesOrderID
ORDER BY CustomerID
OPTION (RECOMPILE);

-- A more complex query
SELECT SOH.CustomerID,
	SOH.OrderDate,
	SOH.STATUS,
	SOH.SalesOrderID
	FROM Sales.SalesOrderHeader AS SOH
	INNER JOIN 
		(SELECT CustomerID, MAX (OrderDate) as ODate
		FROM Sales.SalesOrderHeader
		GROUP BY CustomerID) AS MaxOrdList
	ON MaxOrdList.ODate = SOH.OrderDate
	AND MaxOrdList.CustomerID = SOH.CustomerID
WHERE SOH.CustomerID IN (11276, 11201);

-- Example of statistics and tipping point
-- Return 1 row
SELECT soh.SalesOrderID,soh.DueDate,
       sod.OrderQty,sod.ProductID
FROM Sales.SalesOrderHeader AS soh
	INNER JOIN Sales.SalesOrderDetail AS sod
		ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.CustomerID > 30117;

-- Lots of rows and a very different query plan
SELECT soh.SalesOrderID,soh.DueDate,
       sod.OrderQty,sod.ProductID
FROM Sales.SalesOrderHeader AS soh
	INNER JOIN Sales.SalesOrderDetail AS sod
		ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.CustomerID > 10000;

-- Usually causes some CXPacket waits
SELECT TOP(1000) *, 
    ROW_NUMBER() OVER 
    ( 
        PARTITION BY OrderQty 
        ORDER BY ProductId 
    ) AS r 
FROM Sales.SalesOrderDetail 
ORDER BY SalesOrderDetailId DESC;

--New Solution.  Constant cost regardless of data set size
WITH LatestOrder AS 
	(SELECT 
	SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comment, rowguid, ModifiedDate
	,ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY OrderDate DESC )RowNum
	FROM Sales.SalesOrderHeader
	)
SELECT CustomerID
	,OrderDate
	,Status
	,SalesOrderID
	--, *
	 FROM LatestOrder
WHERE CustomerID IN (11276, 11201)
  AND RowNum = 1;

