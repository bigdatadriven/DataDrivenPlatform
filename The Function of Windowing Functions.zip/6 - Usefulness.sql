USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

-- Now, for the important things that we'll probably do a lot of
-- Find the first row of each PostalCode for this table.
SELECT * FROM Person.Address













SELECT *
FROM (	SELECT *,
			ROW_NUMBER() OVER (PARTITION BY PostalCode ORDER BY AddressID) AS RowNum 
		FROM Person.Address) Z
WHERE RowNum = 1
ORDER BY PostalCode, AddressID








-- Find the gaps in AddressID for this table.
SELECT * FROM Person.Address












-- Not so simple is it?
-- Now let's use our windowing fuctions to make it a bit easier
 select *
   from
 (   select AddressID, 
            LEAD(AddressID) over (order by AddressID) nextRN, 
			LEAD(AddressID) over (order by AddressID) - AddressID as diff
      from Person.Address
 ) z
 where diff <> 1
 order by AddressID