USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

-- Grab 1 field using LAG and LEAD
SELECT  CustomerID, 
		SalesOrderID, 
		OrderDate,
		DATEDIFF(d, LAG(OrderDate) 
			OVER (PARTITION BY CustomerID 
					ORDER BY SalesOrderID),
	 		OrderDate) AS DaysSinceLast,
	    DATEDIFF(d, OrderDate, LEAD(OrderDate) 
			OVER (PARTITION BY CustomerID 
					ORDER BY SalesOrderID)) 
					   AS DaysUntilNext
FROM Sales.SalesOrderHeader 
ORDER BY CustomerID,SalesOrderID;












--Optional OFFSET and default parameters
SELECT	CustomerID, 
		SalesOrderID, 
		OrderDate, 
		LAG(OrderDate, 2, '1/1/2000') 
			OVER (PARTITION BY CustomerID ORDER BY OrderDate) AS Back2Orders, 
		LEAD(OrderDate, 2, '1/1/2000') 
			OVER (PARTITION BY CustomerID ORDER BY OrderDate) AS Fwd2Orders
FROM Sales.SalesOrderHeader; 











--FIRST_VALUE and LAST_VALUE
SELECT	CustomerID, 
		OrderDate, 
		TotalDue, 
		FIRST_VALUE(OrderDate) OVER (PARTITION BY CustomerID 
									ORDER BY SalesOrderID) AS FirstOrderDate 
FROM Sales.SalesOrderHeader
ORDER BY CustomerID, SalesOrderID;

SELECT	CustomerID, 
		OrderDate, 
		TotalDue ,
		LAST_VALUE(OrderDate) OVER (PARTITION BY CustomerID 
									ORDER BY SalesOrderID) AS LastOrderDate 
FROM Sales.SalesOrderHeader
ORDER BY CustomerID, SalesOrderID;


--What is actually wrong with the last_value function? 
--The default frame only goes to current row
SELECT	CustomerID, 
		OrderDate, 
		TotalDue,
		LAST_VALUE(OrderDate) OVER (PARTITION BY CustomerID 
					ORDER BY SalesOrderID
					ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING) AS LastOrderDate 
FROM Sales.SalesOrderHeader
ORDER BY CustomerID, SalesOrderID;