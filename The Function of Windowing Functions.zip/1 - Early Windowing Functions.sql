USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

--Windowing functions introduced in 2005 with the OVER clause
SELECT  SalesOrderID, 
		OrderDate, 
		CustomerID, 
		ROW_NUMBER() OVER (ORDER BY CustomerID) AS RowNbr
FROM Sales.SalesOrderHeader;













--you can also partition the results
SELECT  SalesOrderID, 
		OrderDate, 
		CustomerID, 
		ROW_NUMBER() OVER (PARTITION BY OrderDate ORDER BY CustomerID) AS RowNbr
FROM Sales.SalesOrderHeader;















--What's really the difffence between ROW_NUMBER, RANK, DENSE_RANK, and N-TILE?
SELECT	SalesOrderID 
		, OrderDate
		, CustomerID 
		, ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY OrderDate) As RowNum
		, RANK() OVER (PARTITION BY CustomerID ORDER BY OrderDate) As Rnk
		, DENSE_RANK() OVER (PARTITION BY CustomerID ORDER BY OrderDate) As DenseRnk
		, NTILE(5) OVER (PARTITION BY CustomerID ORDER BY OrderDate) As TheNTile
FROM Sales.SalesOrderHeader
WHERE CustomerID = 11078; 
