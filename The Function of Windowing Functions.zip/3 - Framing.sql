USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

-- Running Totals
SELECT	SalesOrderID,
		OrderDate, 
		CustomerID, 
		TotalDue,
		SUM(TotalDue) OVER (
				PARTITION BY CustomerID 
				ORDER BY OrderDate) AS CustomerRunningTotal
FROM Sales.SalesOrderHeader SOH
ORDER BY CustomerID, OrderDate;







-- And Reverse Rolling Totals?
SELECT	OrderDate, 
		CustomerID, 
		TotalDue,
		SUM(TotalDue) OVER (PARTITION BY CustomerID ORDER BY SalesOrderID 
				ROWS BETWEEN UNBOUNDED PRECEDING and CURRENT ROW) AS RunningTotal,
		SUM(TotalDue) OVER (PARTITION BY CustomerID ORDER BY SalesOrderID 
				ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING) AS ReverseTotal
FROM Sales.SalesOrderHeader SOH
ORDER BY CustomerID, OrderDate;







-- Rolling Average 
WITH Orders AS (
	SELECT DISTINCT OrderDate, Sum(OrderQty) OVER (PARTITION BY OrderDate) AS OrderQty 
	FROM Sales.SalesOrderHeader AS SOH 
	INNER JOIN Sales.SalesOrderDetail AS SOD 
		ON SOH.SalesOrderID = SOD.SalesOrderID)
SELECT	OrderDate, 
		OrderQty, 
		AVG(OrderQty) OVER (ORDER BY OrderDate
					ROWS BETWEEN 10 PRECEDING AND 10 FOLLOWING) AS MovingAvg
FROM Orders
ORDER BY OrderDate;