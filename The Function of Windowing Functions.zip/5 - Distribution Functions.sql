USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

-- The value returned by the CUME_DIST function represents the percent of employees that 
-- have a salary less than or equal to the current employee in the same department. 
-- The PERCENT_RANK function computes the rank of the employee's salary within a department as a percentage. 
SELECT Department, LastName, Rate,   
       CUME_DIST () OVER (PARTITION BY Department ORDER BY Rate) AS CumeDist,   
       PERCENT_RANK() OVER (PARTITION BY Department ORDER BY Rate ) AS PctRank  
FROM HumanResources.vEmployeeDepartmentHistory EDH
JOIN HumanResources.EmployeePayHistory E ON e.BusinessEntityID = edh.BusinessEntityID  
ORDER BY Department, Rate DESC;  







-- Finds the median employee salary in each dept
-- PERCENTILE_CONT Calculates a percentile based on a continuous distribution of the column value in SQL Server. 
-- 					The result is interpolated and might not be equal to any of the specific values in the column.
-- PERCENTILE_DISC calculates the percentile based on a discrete distribution of the column values. 
--					It always returns the actual value
SELECT DISTINCT Name AS DepartmentName,  
      PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY ph.Rate)   
                            OVER (PARTITION BY Name) AS MedianCont,  
      PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY ph.Rate)   
                            OVER (PARTITION BY Name) AS MedianDisc  
FROM HumanResources.Department AS d  
JOIN HumanResources.EmployeeDepartmentHistory AS dh ON dh.DepartmentID = d.DepartmentID  
JOIN HumanResources.EmployeePayHistory AS ph ON ph.BusinessEntityID = dh.BusinessEntityID  
WHERE dh.EndDate IS NULL; 

-- To calculate percentile_cont
-- https://raresql.com/2013/02/13/sql-server-2012-analytic-functions-percentile_cont/