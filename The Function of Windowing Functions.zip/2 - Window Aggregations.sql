USE AdventureWorks2014
GO

/************************************************************************
*
*		The Function of Windowing Functions
*
*		Kevin Wilkie
*
************************************************************************/

-- We all know how to do normal summations
SELECT  CustomerID,
		SUM(TotalDue)
FROM Sales.SalesOrderHeader SOH
GROUP BY CustomerID
ORDER BY CustomerID









-- But now we can sum within windows easily
SELECT  OrderDate, 
		SalesOrderID, 
		CustomerID, 
		TotalDue, 
		SUM(TotalDue) OVER () AS TotalSales
FROM Sales.SalesOrderHeader SOH
ORDER BY CustomerID, OrderDate;

-- Or even grouped by CustomerID
SELECT  OrderDate, 
		SalesOrderID, 
		CustomerID, 
		TotalDue, 
		SUM(TotalDue) OVER (PARTITION BY CustomerID) AS TotalSales
FROM Sales.SalesOrderHeader SOH
ORDER BY CustomerID, OrderDate;